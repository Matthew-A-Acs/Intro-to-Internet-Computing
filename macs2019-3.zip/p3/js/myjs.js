// The event handler function registers the event handlers for the button clicks for the calculators
// The function is called when the DOM content is loaded
function loadedHandler(event) {
    let btnBasic = document.getElementById("btnBasic");
    let btnAdvanced = document.getElementById("btnAdvanced");
    let btnOther = document.getElementById("btnOther");
    btnBasic.addEventListener("click", basicHandler);
    btnAdvanced.addEventListener("click", advancedHandler);
    btnOther.addEventListener("click", otherHandler);
}

// The event handler function gets the value of the input in the basic input box, processes the data, and produces a corresponding output into a div
// The function is called when the basic calculate button is clicked on
function basicHandler(event) {
    let resultsBasic = document.getElementById("resultsBasic");
    let inputBasic = document.getElementById("basicNums").value;
    let inputBasicBox = document.getElementById("basicNums");
    let arrayBasic = process(inputBasic);
    sortA(arrayBasic);
    let valid = validate(arrayBasic);
    if(valid == 1)
        {
            inputBasicBox.classList.remove("bg-danger");
            inputBasicBox.classList.remove("text-white");
            inputBasicBox.classList.add("bg-white");
            inputBasicBox.classList.add("text-black");
            let max = maximum(arrayBasic);
            let min = minimum(arrayBasic);
            let mean = arMean(arrayBasic);
            let median = arrayMedian(arrayBasic); 
            let range = arrayRange(arrayBasic);
            resultsBasic.innerHTML = "<h3>Results</h3><p>Input: " + arrayBasic + "</p><p>Maximum: " + max + "</p><p>Minimum: " + min + "</p><p>Mean: " + mean + "</p><p>Median: " + median + "</p><p>Range: " + range + "</p>"; 
        }
    else if(valid == 0)
        {
            inputBasicBox.classList.remove("bg-white");
            inputBasicBox.classList.remove("text-black");
            inputBasicBox.classList.add("bg-danger");
            inputBasicBox.classList.add("text-white");
            resultsBasic.innerHTML = "<h3 class='text-danger'>Error! Input can't be interpreted.</h3>";
        }
}


// The event handler function gets the value of the input in the advanced input box, processes the data, and produces a corresponding output into a div
// The function is called when the advanced calculate button is clicked on
function advancedHandler(event) {
    let resultsAdvanced = document.getElementById("resultsAdvanced");
    let inputAdvanced = document.getElementById("advancedNums").value;
    let inputAdvancedBox = document.getElementById("advancedNums");
    let arrayAdvanced = process(inputAdvanced);
    sortA(arrayAdvanced);
    let valid = validate(arrayAdvanced);
    if(valid == 1)
        {
            inputAdvancedBox.classList.remove("bg-danger");
            inputAdvancedBox.classList.remove("text-white");
            inputAdvancedBox.classList.add("bg-white");
            inputAdvancedBox.classList.add("text-black");
            let variance = arrayVariance(arrayAdvanced);
            let stdDev = arrayStDev(arrayAdvanced);
            resultsAdvanced.innerHTML = "<h3>Results</h3><p>Input: " + arrayAdvanced + "</p><p>Variance: " + variance + "</p><p>Standard Deviation: " + stdDev + "</p>";
        }
    else if(valid == 0)
        {
            inputAdvancedBox.classList.remove("bg-white");
            inputAdvancedBox.classList.remove("text-black");
            inputAdvancedBox.classList.add("bg-danger");
            inputAdvancedBox.classList.add("text-white");
            resultsAdvanced.innerHTML = "<h3 class='text-danger'>Error! Input can't be interpreted.</h3>";
        }
}

// The event handler function gets the value of the input in the other input box, processes the data, and produces a corresponding output into a div
// The function is called when the other calculate button is clicked on
function otherHandler(event) {
    let resultsOther = document.getElementById("resultsOther");
    let inputOther = document.getElementById("otherNums").value;
    let inputOtherBox = document.getElementById("otherNums");
    let arrayOther = process(inputOther);
    sortA(arrayOther);
    let valid = validate(arrayOther);
    if(valid == 1)
        {
            inputOtherBox.classList.remove("bg-danger");
            inputOtherBox.classList.remove("text-white");
            inputOtherBox.classList.add("bg-white");
            inputOtherBox.classList.add("text-black");
            let sum = totalSum(arrayOther);
            let product = totalProduct(arrayOther);
            resultsOther.innerHTML = "<h3>Results</h3><p>Input: " + arrayOther + "</p><p>Sum: " + sum + "</p><p>Product: " + product + "</p>";
        }
    else if(valid == 0)
        {
            inputOtherBox.classList.remove("bg-white");
            inputOtherBox.classList.remove("text-black");
            inputOtherBox.classList.add("bg-danger");
            inputOtherBox.classList.add("text-white");
            resultsOther.innerHTML = "<h3 class='text-danger'>Error! Input can't be interpreted.</h3>";
        }
}

// The function splits a string into an array based on the commas in the string and parses the resulting array into an array of floats
// Used to process the strings from the input boxes
// The function returns the array of floats
function process(inputString){
    let arrayS = inputString.split(",");
    let arrayN = [];
    for(i=0; i<arrayS.length; i++)
    {
        arrayN[i] = parseFloat(arrayS[i]);
    }
    return arrayN;
}

// The function finds the maximum value of the data inputs by traversing the array and comparing the values of the data
// Used in the basicHandler to find the maximum of the data set
// The function returns the maximum value of the array
function maximum(inputArray){
    let max = inputArray[0];
    for(i=0; i<inputArray.length; i++)
    {
        if(inputArray[i] > max)
        {
            max = inputArray[i];
        }
    }
    return max;
}

// The function finds the minimum value of the data inputs by traversing the array and comparing the values of the data
// Used in the basicHandler to find the minimum of the data set
// The function returns the minimum value of the array
function minimum(inputArray){
    let min = inputArray[0];
    for(i=0; i<inputArray.length; i++)
    {
        if(inputArray[i] < min)
        {
            min = inputArray[i];
        }
    }
    return min;
}

// The function finds and returns the sum of all of the data values in the array
// Used by several functions to calculate the sum for other computations
function totalSum(inputArray){
    let sum = 0;
    for(i=0; i<inputArray.length; i++)
    {
        sum+=inputArray[i];
    }
    return sum;
}

// The function finds and returns the product of all of the data values in the array
// Used in the otherHandler to find the product of the data set
function totalProduct(inputArray){
    let product = 1;
    for(i=0; i<inputArray.length; i++)
    {
        product*=inputArray[i];
    }
    return product;
}

// The function finds the mean value of the data inputs by dividing the sum of the array by the number of elements
// Used in the basicHandler to find the mean of the data set
// The function returns the mean value of the array
function arMean(inputArray){
    let sum = totalSum(inputArray);    
    let mean = sum/(inputArray.length);
    return mean;
}

// The function sorts an array in ascending order
// Used in the event handlers to sort the arrays of floats
function sortA(inputArray){
    inputArray.sort(function(a, b) {
        return a - b;
    });
}

// The function finds the median value of the data inputs by finding the middle number of the array
// or averaging the two middle values
// Used in the basicHandler to find the median of the data set
// The function returns the median value of the array
function arrayMedian(inputArray){
    
    let middle = ((inputArray.length)/2)-1;
    
    if( (inputArray.length)%2 != 0)
        {
            let upper = Math.ceil(middle);
            return inputArray[upper];
        }
    else
        {
            return (inputArray[middle]+inputArray[middle+1])/2;
        } 
}

// The function finds the range of the data inputs by subtracting the minimum from the maximum
// Used in the basicHandler to find the range of the data set
// The function returns the range of the array
function arrayRange(inputArray){
    let max = maximum(inputArray);
    let min = minimum(inputArray);
    
    let range = max-min;
    return range;
}

// The function finds the variance of the data inputs
// Used in the advancedHandler to find the variance of the data set
// The function returns the variance of the array
function arrayVariance(inputArray){
    let sum = 0;
    let mean = arMean(inputArray);
    for(i=0; i<inputArray.length; i++)
    {
        sum+=(inputArray[i]-mean)*(inputArray[i]-mean);
    }
    return sum/(inputArray.length-1);
}

// The function finds the standard deviation of the data inputs by taking the square root of the variance
// Used in the advancedHandler to find the standard deviation of the data set
// The function returns the standard deviation of the array
function arrayStDev(inputArray){
    let variance = arrayVariance(inputArray);
    return Math.sqrt(variance);
}

// The function validates an array of floats by comparing each element to NaN
// Used in the handlers to ensure proper input
// The function returns true if the data is valid and false if it is not
function validate(array){
    let valid = 1;
    for(i=0; i<array.length; i++)
    {
        if( isNaN(array[i]) )
            {
                valid = 0;
            }
    }
    return valid;
}

// Registers an event handler for the DOM content loaded event
window.addEventListener("DOMContentLoaded", loadedHandler);